# Player Fledge
import random
from cribbagegame import CribbageGame
from player import CribbagePlayer
from playerRandyDumb import PlayerRandyDumb
from playingcards import Deck, Card, strHand
from scoring import handCombos, scoreHand, pegPlay


class PlayerFledge(CribbagePlayer):

    def __init__(self, nickname=None):
    	super().__init__()  # Start with the inhereitance of all variables and methods from the parent
    	# Alternative would be: CribbagePlayer.__init__(self)  to just start with parent's initialization
    	# Now alter or add initializations
    	self.name = "Fledge"
    	self.type = "Computer"
    	self.version = "0.3"
    	self.chat = "Greetings, looking forward to a good game"

    #def __str__(self):
     #   return str(self.name)

    #def num(self):
    #    return int(self.playerNum)

    def selectCrib(self, hand, numCards=2):
        # Keep the 4 best scoring cards
        options = handCombos(hand, 4, 4)
        bestPoints = 0
        bestHand = []
        for candidate in options:
            points, s = scoreHand(candidate)
            if points >= bestPoints:
                bestPoints = points
                bestHand = candidate

        cards = hand[:]
        for card in bestHand:
            cards.remove(card)
        assert len(cards) == 2, "Crib length is faulty" + strHand(cards)
        return cards

    def selectCard(self, hand, table, legalCards):
        bestPegPoints = 0
        bestPegCard = []
        for card in legalCards:
            nextTable = table[:]
            nextTable.append(card)
            points, s = pegPlay(nextTable)
            if points >= bestPegPoints:
                bestPegPoints = points
                bestPegCard = card
        return bestPegCard

    def msg(self, message):
        print(message) # Incoming message from the game (like what the other player did)

    def chatMsg(self, message):
        self.chat = message # Message from other player someday    

def cardsTotal(cards):
    #Get the total value of cards in the current active sequence.
    #:param sequence_start_idx: Table index where current sequence begins.
    #:return: Total value of cards in active sequence.
    value = 0
    for c in cards: 
        value += c.get_value()
    return value

def main():
    # run locally
    Fledge = PlayerFledge()

    s = str(Fledge) + " a " + Fledge.type + " player, version " + Fledge.version
    print(s)
    print("I am player #" + str(Fledge.num()))


    players = [PlayerRandyDumb(nickname="Randy"), PlayerFledge()]
    game = CribbageGame(players=players)
    game.commentary = True  # Announce gameplay
    game.playGame()

if __name__ == '__main__':
    main()