"""Cribbage game."""
import random
from playingcards import Deck, Card, strHand
import scoring
from scoring import pegPlay, scoreHand

# Player roster
from player import HumanPlayer
from playerRandyDumb import PlayerRandyDumb
#from playerFledge import PlayerFledge


class CribbageGame:
    """Main cribbage game class."""
    
    # Class-level constants
    MAX_SCORE = 121  # game ends at this score
    CRIB_SIZE = 4  # size of the crib

    def __init__(self, players):
        self.commentary = False # default is not to print play by play
        self.players = players  #: the two players
        assert len(self.players) == 2, "Currently, only 2-player games are supported."
        self.handsPlayed = 0
        self.score = [0, 0] 
        self.pegs = [[0, 0], [0, 0]] # front peg is [0], rear is [1]
        self.dealerX = random.choice([0, len(players)-1]) # This is the cut for who deals first hand
        self.gameOver = False;
       
    def reset(self):
        # Resets scores to let same players play again
        self.handsPlayed = 0
        self.score = [0, 0] 
        self.pegs = [[0, 0], [0, 0]] # front peg is [0], rear is [1]
        self.dealerX = (self.dealerX + 1) % 2
        self.gameOver = False;
  
    def comment(self, s):
        # display commentary
        if self.commentary:
            print(s)

    def playGame(self):
        #Initiate game.

        self.comment("----------------------------------------------------------------------------")
        self.comment("Starting new game matching " + str(self.players[0]) + " against " + str(self.players[1]))
        self.players[0].playerNum = 0
        self.players[1].playerNum = 1
        # print("PEGS: " + str(self.pegs) + " Score: " + str(self.score))

        # Announce results of coin flip
        self.comment("Coin flip. " + str(self.players[self.dealerX]) + " is dealer.")
        self.players[self.dealerX].myDeal = True # Information for the player

        while not self.gameOver:
            self.handsPlayed += 1
            self.comment(" ")
            self.comment("---------- Hand #" + str(self.handsPlayed))
            hand = CribbageHand(self)
            hand.playHand(self)
            # Switch dealer
            self.dealerX = (self.dealerX + 1) % 2 # Assumes 2 players is only option

        #Game is over, declare the winner
        if self.score[0] >= self.MAX_SCORE: winner, loser = 0, 1
        else: winner, loser = 1, 0
        self.comment("Game is over, " + str(self.players[winner]) + " is the winner!")
        self.comment("Final score: "
                        + str(self.players[winner]) + " " + str(self.score[winner]) + ", "
                        + str(self.players[loser]) + " " + str(self.score[loser]))

    def peg(self, playerX, points):
        """Add points for a player.

        :param playerX: player number who should receive points.
        :param points: Number of points to add to the player.
        :return: None
        """
        front, rear = 0, 1
        assert points > 0, "You must peg 1 or more points."
        #print("P:" + str(self.pegs[0]) + " to " + str(self.pegs[1]) + " with " + str(points))
        self.pegs[playerX][rear] = self.pegs[playerX][front] # Front peg is [0] rear peg is [1]
        self.score[playerX] += points
        #print("S:" + str(self.score[0]) + " to " + str(self.score[1]))
        self.pegs[playerX][front] += points # move the front peg
        if self.pegs[playerX][front] >= self.MAX_SCORE:
            self.pegs[playerX][front] = self.MAX_SCORE
            self.gameOver = True  

class CribbageHand:
    """Individual round (hand) of cribbage."""

    def __init__(self, game):
        # Replenish deck for each hand
        self.deck = Deck()
        # self.hands = [[[{player: [] for player in game.players}]]]
        self.hands = [[], []]
        self.crib = []
        self.starter = None
        self.dealer = game.dealerX # An index into game.players
        self.nondealer = (game.dealerX + 1) % 2

    def playHand(self, game):
        # shuffle and deal
        self._deal(game)
        s = str(game.players[self.dealer]) + " Deals: "
        s += str(game.players[0]) + "'s hand: " + strHand(self.hands[0]) + ", "
        s += str(game.players[1]) + "'s hand: " + strHand(self.hands[1])
        game.comment(s)

        # collect crib contributions
        s = ''    
        for i in range(2):
            p = game.players[i]
            cards_to_crib = p.selectCrib(hand=self.hands[i], numCards=2)
            if len(s): s += ", "
            s += str(p) + " cribbed " + strHand(cards_to_crib)
            if not set(cards_to_crib).issubset(set(self.hands[i])):
                raise IllegalCardChoiceError("Crib cards selected are not part of player's hand.")
            elif len(cards_to_crib) != 2:
                raise IllegalCardChoiceError("Wrong number of cards sent to crib.")
            else:
                self.crib += cards_to_crib
                p.cribCards = cards_to_crib[:]
                for card in cards_to_crib:
                    self.hands[i].remove(card)
                p.handDelt = self.hands[i][:]
        assert len(self.crib) == game.CRIB_SIZE, "Crib size is not %s" % game.CRIB_SIZE

        # Announce modified hands
        s += ", Hands are now " + strHand(self.hands[0]) 
        s += " and " + strHand(self.hands[1])
        game.comment(s)

        # Cut the starter card
        self.deck.cut(cut_point=None)
        self.starter = self.deck.draw()
        s = "The starter card is " + str(self.starter)
        if self.starter.rank['name'] == 'jack':
            game.peg(self.dealer, 2)
            s += ", 2 points to %s for his heels." % str(game.players[self.dealer])
        game.players[0].starter = game.players[1].starter = self.starter
        game.comment(s)

        # Make a copy of the hands
        pegHands = [self.hands[0][:], self.hands[1][:]] 
        lastToPlay = self.dealer
        # Continue to peg this hand until all cards are played
        while (len(pegHands[0]) + len(pegHands[1])) and (not game.gameOver):

            self.table = []
            calledGo = -1 # Set to player inde when go called
            lead = lastToPlay # This will be switched before play
            while not game.gameOver: # Loop for a round of pegging
                if len(self.table) == 0:
                    s = "Table is clear: "
                else:
                    s = "Table is " + strHand(self.table)
                    s += "=" + str(self.tableTotal(self.table)) + " "
                lead = (lead + 1) % 2 # switch the lead
                s += str(game.players[lead]) + " " + str(pegHands[lead]) + " "

                # Select card to play
                validCards = self.legalCards(pegHands[lead])
                if not validCards:           
                    if pegHands[lead]:
                        if calledGo == -1:
                            calledGo = lead
                            s += "says GO"
                            game.comment(s)
                    continue # switch lead
                elif len(validCards) == 1:
                    card = validCards[0] # Only one card to play
                    s += "Must play "
                else:
                    # passing arguments by value
                    card = game.players[lead].selectCard(
                                hand=pegHands[lead][:], 
                                table=self.table[:], 
                                legalCards=validCards[:])
                    s += "plays "

                # Play the selected card
                self.table.append(card)
                pegHands[lead].remove(card)
                s += str(card) + " "
                lastToPlay = lead

                # Pegging points?
                pts, des = pegPlay(self.table)
                if pts > 0:
                    s += des
                    game.peg(lead, pts)
                    if self.tableTotal(self.table) == 31:
                        game.comment(s)
                        break

                # Can anyone still play?
                if (len(self.legalCards(pegHands[0])) + len(self.legalCards(pegHands[1]))) == 0:
                    if pts > 0: s += "plus "
                    s += "1 point for last card"
                    game.comment(s)
                    game.peg(lead, 1)
                    break # end of round

                # Say what happened
                game.comment(s)

        # Pegging complete
        # Score the non-dealer first
        if not game.gameOver:
            game.comment("Pegging is finished.")
            nonDealer = (self.dealer +1) % 2
            points, description = scoreHand(self.hands[nonDealer],
                                            self.starter, crib=False)
            s = str(game.players[nonDealer]) + "'s hand "
            s += strHand(self.hands[nonDealer]) + "+" + str(self.starter)
            s += " scored " + str(points) + " points."
            game.comment(s)
            s = "    " + description
            game.comment(s)
            if points: game.peg(nonDealer, points)

        # Score the dealer next
        if not game.gameOver:
            points, description = scoreHand(self.hands[self.dealer],
                                            self.starter, crib=False)
            s = str(game.players[self.dealer]) + "'s hand "
            s += strHand(self.hands[self.dealer]) + "+" + str(self.starter)
            s += " scored "+ str(points) + " points."
            game.comment(s)
            s = "    " + description
            game.comment(s)
            if points: game.peg(self.dealer, points)   

        # Score the crib
        if not game.gameOver:
            points, description = scoreHand(self.crib,
                                            self.starter, crib=True)
            s = str(game.players[self.dealer]) + "' crib "
            s += strHand(self.crib) + "+" + str(self.starter)
            s += " scored " + str(points) + " points."
            game.comment(s)
            s = "    " + description
            game.comment(s)
            if points: game.peg(self.dealer, points)

        # Report on the score
        if game.score[0] == game.score[1]:
            s = "The game is tied at " + str(game.score[0]) + " points."
        else:
            leader = 0 if game.score[0] > game.score[1] else 1
            s = str(game.players[leader]) + " has " + str(game.score[leader]) + " points, with a "
            s += str(abs(game.score[0] - game.score[1])) + " point lead."
        game.comment(s)

        return # End of hand
 

    def _deal(self, game):
        # May just move into playHand method
        # Shuffle cards.
        shuffles = 3  # ACC Rule 2.1
        for i in range(shuffles):
            self.deck.shuffle()
        # Cut
        self.deck.cut(cut_point=None)
        # deal
        cards_per_player = 6
        for i in range(cards_per_player):
            self.hands[0].append(self.deck.draw())
            self.hands[1].append(self.deck.draw())

    def legalCards(self, hand):
        # See if any valid cards to play, return the list of valid cards
        validCards = hand.copy()
        i = 0
        while i < len(validCards):
            if validCards[i].get_value() + self.tableTotal(self.table) > 31:
                validCards.pop(i)
            else: i += 1
        return validCards

    def tableTotal(self, cards):
        #Get the total value of cards in the current active sequence.
        #:param sequence_start_idx: Table index where current sequence begins.
        #:return: Total value of cards in active sequence.
        value = 0
        for c in cards: 
            value += c.get_value()
        return value


def main():
    # players = [CribbagePlayer(Random), CribbagePlayer(Random)]
    players = [PlayerRandyDumb(nickname="Randy"),
               PlayerRandyDumb(nickname="Dumby")]
    game = CribbageGame(players=players)
    game.commentary = True  # Announce gameplay
    game.playGame()

"""
if __name__ == '__main__':
    main()
"""
