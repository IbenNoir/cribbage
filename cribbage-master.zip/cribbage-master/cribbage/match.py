"""Cribbage Matchegame.

Allows an external call to CribbageGame() with selected players 
This also means that the CribbageGame will not announce situation
Therefore it is up to the players to provide game commentary.  """

# import random
# import scoring
from roster import playerRoster
from playerRandyDumb import PlayerRandyDumb
from playerFledge import PlayerFledge
from cribbagegame import CribbageGame
# from playingcards import Deck

MATCH_GAMES = 1000

def main():
	# run locally
	Fledge = PlayerFledge()
	Dummy = PlayerRandyDumb()
	players = [Fledge, Dummy]

	wins = [0,0]
	totalPoints = [0,0]
	highestScore = [0,0]
	lowestScore = [200,200]
	bestWin = [[0,0],[0,0]]

	game = CribbageGame(players)
	print()
	print("Playing ", MATCH_GAMES, " games between ",
		  players[0]," and ", players[1])

	for i in range(MATCH_GAMES):
		game.reset()
		game.playGame()
		if game.score[0] > game.score[1]:
			winner, loser = 0, 1
		else:
			winner, loser = 1, 0

		wins[winner] += 1
		for i in range(2):
			totalPoints[i] += game.score[i]
			highestScore[i] = max(highestScore[i], game.score[i])
			lowestScore[i] = min(lowestScore[i], game.score[i])
			margin = game.score[i] - game.score[(i + 1) % 2]
			if margin > bestWin[i][0] - bestWin[i][1]:
				bestWin[i][0] = game.score[i]
				bestWin[i][1] = game.score[(i + 1) % 2]

		# should test for a minute passed to print progress

	# The match is over
	if wins[0] > wins[1]:
		winner, loser = 0, 1
		print(str(players[winner])," has won the match.")
	elif wins[0] < wins[1]:
		winner, loser = 1, 0
		print(str(players[winner])," has won the match.")
	else:
		winer, loser = 0, 0
		print("The match ended in a tie!")

	print()
	for i in range(2):
		print(str(players[i])," statistics:")
		print("    Wins: ", wins[i], ", Losses: ", MATCH_GAMES - wins[i])
		print("    Highest Score: ", highestScore[i], 
				", Lowest Score: ", lowestScore[i],
				", Average Score: ", totalPoints[i] / MATCH_GAMES)
		if bestWin[i][0] - bestWin[i][1] > 0:
			s = "    Greatest Victory: "
		else:
			s = "    Closest Game: "
		print(s, bestWin[i][0], " to ", bestWin[i][1])
	

if __name__ == '__main__':
    main()
