"""Cribbage score conditions used during and after rounds."""
from  playingcards import Deck, Card, strHand, str_to_hand
                                                                               

def scoreHand(hand, starter=None, crib=False):
    # If starter is None, evaluate score without it
    assert len(hand) == 4, "scoreHand: hand does not have 4 cards"
    points, description = 0, ""
    hand5 = hand[:]  # copy of hand
    if starter is not None:
        hand5.append(starter)
    pts, des = _score15(hand5)
    points += pts
    description += des
    pts, des = _scoreStraight(hand5)
    points += pts
    description += des
    pts, des = _scorePair(hand5)
    points += pts
    description += des
    pts, des = _scoreFlush(hand, starter)
    points += pts
    description += des
    if starter is None:
        pts, des = _scoreNobs(hand, starter)
        points += pts
        description += des
    return points, description
    # Check for nobes


def _score15(hand):
    pts, des = 0, ""  # Return values
    for i in range(len(hand) - 1):
        total = hand[i].get_value()
        h = [hand[i]]
        j = i + 1;
        while (j < len(hand)):
            total += hand[j].get_value()
            h.append(hand[j])
            if total >= 15:
                if total == 15:
                    pts += 2
                    des += "15" + strHand(h) + "-" + str(pts) + " "
                total -= hand[j].get_value()
                h.remove(hand[j])
            j += 1
    return pts, des


def _scoreStraight(hand):
    points , description = 0, ""
    if len(hand) == 5:
        if _isStraight(hand):
            points = 5
            ranked = sorted(hand, key=lambda x: x.rank['rank'])
            description = "straight" + strHand(ranked) + "-5 "
            return points, description
    combos = handCombos(hand, 4, 4)
    for cards in combos:
        if _isStraight(cards):
            points += 4
            ranked = sorted(cards, key=lambda x: x.rank['rank'])
            description += "straight" + strHand(ranked) + "-4 "
    if points:
        return points, description
    combos = handCombos(hand, 3, 3)
    for cards in combos:
        if _isStraight(cards):
            points += 3
            ranked = sorted(cards, key=lambda x: x.rank['rank'])
            description += "straight" + strHand(ranked) + "-3 "
    return points, description


def _scorePair(hand):
    points, description = 0, ""
    rankHits = [0]*13
    for card in hand:
        rankHits[card.get_rank() - 1] += 1
    pts = 0
    for i in range(13):
        if rankHits[i] > 1:
            pair = []
            for card in hand:
                if card.get_rank() == i + 1:
                    pair.append(card)
            if rankHits[i] == 2:
                pts = 2
                description += "Pair" + strHand(pair) + "-2 "
            elif rankHits[i] == 3:
                pts = 6
                description += "RoyalPair" + strHand(pair) + "-6 "
            elif rankHits[i] == 4:
                pts = 12
                description += "DoubleRoyalPair" + strHand(pair) + "-12 "
            points += pts
    return points, description


def _scoreFlush(hand, starter):
    points, description = 0, ""
    suit = hand[-1].get_suit()
    for i in range(len(hand) - 1):
        if hand[i].get_suit() != suit:
            return points, description
    points = 4
    description = strHand(hand)
    if len(hand) == 5:
        points = 5
    elif starter is not None:
        if starter.get_suit() == suit:
            points = 5
            tempHand = hand[:]
            tempHand.append(starter)
            description = strHand(tempHand)
    description = "flush-" + description + str(points)
    return points, description


def _scoreNobs(hand, starter):
        points, description = 0, ""
        if starter is not None:
            for card in hand:
                if (card.rank['name'] == 'jack') \
                and (card.get_suit() == starter.get_suit()):
                    points = 1
                    description = "nobs[" + str(card) + "]-1"
        return points, description


def handCombos(hand, comboMin, comboMax):
    # Builds a list of all possible conbinations of hand
    # comboMin and comboMax specify min and max lenth of combinations
    results = []
    comboLen = comboMin

    def _comboBuilder(hand, data, start, end, index):
        # Called recusively and populates results
        # hand[]: list of type Card
        # data[]: used to build a hand cobination 
        # start, end, index: indexes into hand[] and data[] 
        nonlocal results  
        nonlocal comboLen

        # Found a combination at right length
        if (index == comboLen):     
            results.append(data[:])
            return

        i = start
        # adjust indicies, populate data[] and call recursively 
        while(i <= end and end - i + 1 >= comboLen - index): 
            data[index] = hand[i]
            i += 1 
            _comboBuilder(hand, data, i, end, index + 1) 
        return

    # Executable section of handCombos()
    while comboLen <= comboMax:
        data = [0]*comboLen  # working storage
        _comboBuilder(hand, data, 0, len(hand) - 1, 0)
        comboLen += 1
    return results

def pegPlay(table):
    points, description = 0, ""
    tableValue = 0
    for c in table: 
        tableValue += c.get_value()
    if tableValue == 15:
        description += "15 for 2 points "
        points = 2
    if tableValue == 31:
        description += "31 for 2 points "
        points = 2
    pts, des = _pegPair(table)
    points += pts
    description += des
    pts, des = _pegStraight(table)
    points += pts
    description += des
    return points, description


def _pegPair(table):
    points, description = 0, ""
    if (len(table) >= 2) and (table[-2] == table[-1]):
        description = "pair for 2 points "
        points = 2
        if (len(table) >= 3) and (table[-3] == table[-2]):
            description = "royal pair for 6 points "
            points = 6
            if (len(table) >= 4) and (table[-4] == table[-3]):
                description = "double royal pair for 12 points "
                points = 12
    return points, description


def _pegStraight(table):
    # check table to see if we pegged a straight
    points, description = 0, ""
    x = 3 # Minimum straight length
    while len(table) >= x:
        if _isStraight(table[-x:]):
            points = x
            description = "straight for " + str(points) + " points "
        x += 1
    return points, description

def _isStraight(cards):
    # Takes a list of cards and returns true if they comprise a straight
    ranked = sorted(cards, key=lambda x: x.rank['rank']) # Make a copy
    for i in range(len(ranked) - 1):
        # print(ranked[i].rank['rank'], ranked[i + 1].rank['rank'] + 1)
        if ranked[i].rank['rank'] != ranked[i + 1].rank['rank'] - 1:
            return False
    return True



def main():
    # testing area

    print()
    print("scoring.py function tests")
    print()

    print("isStraight(cards):")
    tests = ["AC 2H 3S", "10D 9C JH", "4C 6C 8C 7C", "2S 4C 6D 5S 3H",
             "4H 5H", "4h 5S 6D 6C 7H", "AC 5S AD AS", "5H 4D 4c 4H",
             "5C 5D 5S 5H", "10S 5H", "10S 5H 9D 7C"]
    for test in tests:
        hand = str_to_hand(test)
        print(test, str(hand), _isStraight(hand))

    print()
    print("pegStraight(table):")
    for test in tests:
        hand = str_to_hand(test)
        pts, msg = _pegStraight(hand)
        print(str(hand), pts, msg)

    print()
    print("pegPair(table):")
    for test in tests:
        hand = str_to_hand(test)
        pts, msg = _pegPair(hand)
        print(str(hand), pts, msg)

    print()
    print("pegPlay(table):")
    for test in tests:
        hand = str_to_hand(test)
        pts, msg = pegPlay(hand)
        print(str(hand), pts, msg)

    tests4 = ["10h 5c jh 5d", "AH kH 2H 3H", "7D 7C 8D 9D", "4H 4D 6H 5C",
              "QH 5D 5C QS"]
    tests5 = ["10h 5c jh 5d 5H", "AH kH 2H 3H", "7D 8D 9D 10H jH",
              "4H 4D 6H 5C 5D", "QH 5D 5C QS QC", "2H 3H 2C 3C 10D",
              "2H 7H 7S 9C 4S", "4C 6D 4S 6H 4H"]

    print()
    print("score15(hand):")
    tests = tests4 + tests5
    for test in tests:
        hand = str_to_hand(test)
        pts, msg = _score15(hand)
        print(str(hand), pts, msg)

    print()
    print("_scorePair(hand):")
    for test in tests:
        hand = str_to_hand(test)
        pts, msg = _scorePair(hand)
        print(str(hand), pts, msg)

    print()
    print("handCombos(hand, minLength, maxLength):")
    test = "JC QH JD QS JH"
    hand = str_to_hand(test)
    print(test + " resuted in:")
    result = handCombos(hand, 2, 4)
    for i in range(len(result)):
        print(str(result[i]))

 
if __name__ == '__main__':
    main()







