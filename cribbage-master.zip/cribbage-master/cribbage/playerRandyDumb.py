# Player RandyDumb
import random
from player import CribbagePlayer
from playingcards import Deck, Card


class PlayerRandyDumb(CribbagePlayer):

    def __init__(self, nickname=None):
    	super().__init__()  # Start with the inhereitance of all variables and methods from the parent
    	# Alternative would be: CribbagePlayer.__init__(self)  to just start with parent's initialization
    	# Now alter or add initializations
    	self.name = "RandyDumb"
    	if nickname != None: self.name = nickname
    	self.type = "Computer"
    	self.version = "1.0"
    	self.chat = "Howdy, looking forward to a legal game"

    def selectCrib(self, hand, numCards):
        return random.sample(hand, numCards)

    def selectCard(self, hand, table, legalCards):
        return random.choice(legalCards)   
        
        
def main():
    # run locally
    Me = PlayerRandyDumb()

    s = str(Me) + " a " + Me.type + " player, version " + Me.version
    print(s)
    print("I am player #" + str(Me.num()))
    print(Me.chat)

if __name__ == '__main__':
    main()