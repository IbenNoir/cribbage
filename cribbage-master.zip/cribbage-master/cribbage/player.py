"""
player.py contains the CribbagePlayer class from which new players can be built.
Each individual player should be in it's own file, and can run independently.

Shareable player functions should also be placed in this module.
"""
import random
from playingcards import Deck, Card

# Import player classes
# from playerRandyDumb import PlayerRandyDumb
# from playerFledge import PlayerFledge
# playerRoster = [PlayerRandyDumb, PlayerFledge]

class CribbagePlayer:
    # Base player class

    def __init__(self, nickname=None):
        # Player identity - filled in by child objects
        self.name = "Default"
        self.type = "Base" # Current types: Base, Human, Computer
        self.version = "0.3"
        self.chat = "" # A message for other players

        # Game situalization information populated by CribbageGame
        self.playerNum = -1 # Will be set to 0 or 1 when in a game
        self.numPlayers = 2 # Currently only 2 is supported
        self.score = [0,0] # Your score is score[self.playerNum]
        self.myDeal = False # To assist in picking crib cards
        self.handDelt = [] # Your original hand after crib selection
        self.cribCards = [] # the cards you contributed to the crib
        self.starter = None # The starter card, populated after crib contribution

    def __str__(self):
        return str(self.name)

    def num(self):
        return int(self.playerNum)

    def selectCrib(self, hand, numCards=2):
        cards = [] # should be an array of cards
        raise NotImplementedError
        return cards

    def selectCard(self, hand, table, legalCards):
        card = None # Should be a card class
        raise NotImplementedError
        return card

    def msg(self, message):
        print(message) # Incoming message from the game (like what the other player did)

    def chatMsg(self, message):
        self.chat = message # Message from other player someday


class HumanPlayer(CribbagePlayer):
    """Interface for a human user to play."""

    def present_cards_for_selection(self, cards, n_cards=1):
        """Presents a text-based representation of the game via stdout and prompts a human user for decisions.

        :param cards: list of cards in player's hand
        :param n_cards: number of cards that player must select
        :return: list of n_cards cards selected from player's hand
        """
        cards_selected = []
        while len(cards_selected) < n_cards:
            s = ""
            for idx, card in enumerate(cards):
                s += "(" + str(idx + 1) + ") " + str(card)
                if card != cards[-1]:
                    s += ","
                s += " "
            msg = "Select a card: " if n_cards == 1 else "Select %d cards: " % n_cards
            print(s)
            selection = input(msg)
            card_indices = [int(s) for s in selection.split() if s.isdigit()]
            for idx in card_indices:
                if idx < 1 or idx > len(cards):
                    print("%d is an invalid selection." % idx)
                else:
                    cards_selected.append(cards[idx-1])
        return cards_selected

    def selectCrib(self, hand, numCards=2):
        return self.present_cards_for_selection(cards=hand, n_cards=2)

    def selectCard(self, hand, table, legalCards):
        return self.present_cards_for_selection(cards=hand, n_cards=1)[0]

def main():
    p = CribbagePlayer()
    print("CribbagePlayer version ", p.version)
    print()
    #print("Roster of players:")
    #for p in cribbageRoster:
    #    print(p.name," version ",p.version)


if __name__ == '__main__':
    main()
