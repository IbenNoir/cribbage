import random

class Deck:
    SUITS = {
        'hearts': {'name': 'hearts', 'symbol': '♥', 'letter': "H", 'unicode_flag': 'B'},
        'diamonds': {'name': 'diamonds', 'symbol': '♦', 'letter': "D", 'unicode_flag': 'C'},
        'clubs': {'name': 'clubs', 'symbol': '♣', 'letter': "C", 'unicode_flag': 'D'},
        'spades': {'name': 'spades', 'symbol': '♠', 'letter': 'S', 'unicode_flag': 'A'}
    }

    RANKS = {
        'ace': {'name': 'ace', 'symbol': 'A', 'value': 1, 'rank': 1, 'unicode_flag': '1'},
        'two': {'name': 'two', 'symbol': '2', 'value': 2, 'rank': 2, 'unicode_flag': '2'},
        'three': {'name': 'three', 'symbol': '3', 'value': 3, 'rank': 3, 'unicode_flag': '3'},
        'four': {'name': 'four', 'symbol': '4', 'value': 4, 'rank': 4, 'unicode_flag': '4'},
        'five': {'name': 'five', 'symbol': '5', 'value': 5, 'rank': 5, 'unicode_flag': '5'},
        'six': {'name': 'six', 'symbol': '6', 'value': 6, 'rank': 6, 'unicode_flag': '6'},
        'seven': {'name': 'seven', 'symbol': '7', 'value': 7, 'rank': 7, 'unicode_flag': '7'},
        'eight': {'name': 'eight', 'symbol': '8', 'value': 8, 'rank': 8, 'unicode_flag': '8'},
        'nine': {'name': 'nine', 'symbol': '9', 'value': 9, 'rank': 9, 'unicode_flag': '9'},
        'ten': {'name': 'ten', 'symbol': '10', 'value': 10, 'rank': 10, 'unicode_flag': 'A'},
        'jack': {'name': 'jack', 'symbol': 'J', 'value': 10, 'rank': 11, 'unicode_flag': 'B'},
        'queen': {'name': 'queen', 'symbol': 'Q', 'value': 10, 'rank': 12, 'unicode_flag': 'D'},
        'king': {'name': 'king', 'symbol': 'K', 'value': 10, 'rank': 13, 'unicode_flag': 'E'}
    }

    def __init__(self):
        self.cards = []
        for suit in self.SUITS:
            for rank in self.RANKS:
                self.cards.append(Card(rank=self.RANKS[rank], suit=self.SUITS[suit]))
        assert len(self.cards) == 52, "Deck has %i cards" % len(self.cards)

    def __str__(self):
        s = ''
        for card in self.cards:
            s += (str(card) + " ")
        return s

    def __len__(self):
        return len(self.cards)

    def shuffle(self):
        random.shuffle(self.cards)

    def draw(self):
        return self.cards.pop()

    def cut(self, cut_point):
        len_precut = len(self.cards)
        if cut_point is None:
            cut_point = random.randrange(len(self.cards))
        self.cards = self.cards[cut_point:] + self.cards[:cut_point]
        assert len(self.cards) == len_precut, "Cards lost in cut."


class Card:
    def __init__(self, rank, suit):
        self.rank = rank
        self.suit = suit
        self.tupl = (str(rank['symbol']), str(suit['symbol']))
        self.text = str(rank['symbol']) + str(suit['letter'])

    def __str__(self):
        return str(self.rank['symbol'] + self.suit['symbol'])

    def __repr__(self):
        return str(self)

    def __lt__(self, other):
        if type(other) == Card:
            return self.rank['rank'] < other.rank['rank']
        elif type(other) == int:
            return self.rank['rank'] < other
        else:
            raise NotImplementedError

    def __gt__(self, other):
        if type(other) == Card:
            return self.rank['rank'] > other.rank['rank']
        elif type(other) == int:
            return self.rank['rank'] > other
        else:
            raise NotImplementedError

    def __eq__(self, other): # Compares rank (1-13) not suit
        if type(other) == Card:
            return self.rank['rank'] == other.rank['rank']
        elif type(other) == int:
            return self.rank['rank'] == other
        else:
            raise NotImplementedError

    def __add__(self, other):
        if type(other) == Card:
            return self.rank['value'] + other.rank['value']
        elif type(other) == int:
            return self.rank['value'] + other
        else:
            raise NotImplementedError

    def is_card(self, card):
        return (self.rank['name'] is card.rank['name']) and (self.suit['name'] is card.suit['name'])

    def get_value(self): # Pegging value (1-10)
        return self.rank['value']

    def get_suit(self):
        return self.suit['name']

    def get_rank(self):
        return self.rank['rank']

    def get_txt(self):
        return str(self.rank['symbol'] + self.suit['letter'])

    def __hash__(self):
        return hash(self.tupl)


def str_to_hand(text, cards=None):
    # This function takes a string of cards separated by spaces and returns a list of card objects
    #    Example of text "AC 10S 3H"
    # The second argument is a list of acceptable cards
    # If the second parameter is omitted, all cards are valid
    hand = []
    if not cards:
        deck = Deck()
        cards = deck.cards
    texts = text.upper().split()     
    # remove duplicates
    i = len(texts)
    while i > 1:
        i -= 1
        if texts.count(texts[i]) > 1:
            texts.pop(i)
    # Looks for matches
    for textCard in texts:
        for card in cards:
            if textCard == card.text:
                hand.append(card)
                break
    return hand

def strHand(hand):
    # same as str(hand) but without the commas
    s = "["
    for card in hand:
        s += str(card) + " "
    s = s.strip() + "]"
    return s

def main():
    # testing area
    print("Testing str_to_hand function using entire deck:")
    tests = [("AC AD JC JD 10S 5D AC", "Remove Duplicate AC"),
             ("ac AD jc Jd 10s 5d", "Upshifts lower case"),
             ("AC, AD , JC, JD, 10S, 5D, AC", "Works with commas"),
             ("AC ,AD,JC ,JD,10S,5D", "works commas instead of spaces"),
             ("AC AD JCJD 10S shit 5D", "ignores non-cards"),
             ("   AC JD    AS    ", "Irregular spacing"),
             ("I can't get this to work", "works when nothing is valid"),
             ("", "works with nothing")]
    for test in tests:
        text = test[0]
        msg = " " + test[1]
        hand = str_to_hand(text)
        print('"' + text + '" yields ' + strHand(hand) + msg)

    print()
    print("Testing str_to_hand against a valid card list")
    tests = [("AD AS 3H 10D JS KC", "AD AS 3H 10D JS KC", "same"),
             ("AC AD AS 3H 3C 10H 10D JC JS KC KS", "AC 3C 10D kS", "subset"),
             ("AC AD AS 3H 3C 10H 10D JC JS KC KS", "AH 3c 10D KC", "AH invalid")]
    for test in tests:
        validCards = str_to_hand(test[0])
        text = test[1]
        msg = " " + test[2]
        hand = str_to_hand(text, validCards)
        print('"' + text + '" from ' + str(validCards) + "=" + strHand(hand) + msg)


if __name__ == '__main__':
    main()
   
