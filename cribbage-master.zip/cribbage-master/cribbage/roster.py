from player import CribbagePlayer
from playerRandyDumb import PlayerRandyDumb
from playerFledge import PlayerFledge

playerRoster = [PlayerRandyDumb(), PlayerFledge()]
playerClasses = [type(PlayerRandyDumb), type(PlayerFledge)]

def main():
	p = CribbagePlayer()
	print("CribbagePlayer version ", p.version)
	print()
	print("Roster of players:")
	for i in range(len(playerRoster)):
		player = playerRoster[i]
		print(player.name," version: ", player.version,
						  " Class: ", playerClasses[i])
	return


if __name__ == '__main__':
	main()

